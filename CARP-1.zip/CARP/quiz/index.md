# The UK Copyright Advisor aims to give online information (but not legal advice) on these items:

- %start% [An audio file](quiz/1.md) %end%
- %start% [A book chapter](quiz/2.md) %end%
- %start% [Computer code](quiz/3.md) %end%
- %start% [An image (including diagrams, photos and mind maps)](quiz/4.md) %end%
- %start% [A journal article](quiz/5.md) %end%
- %start% [A map (excluding diagrams and mind maps)](quiz/6.md) %end%
- %start% [A video file](quiz/7.md) %end%